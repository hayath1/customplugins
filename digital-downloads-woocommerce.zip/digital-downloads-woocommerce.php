<?php
/**
 * Plugin Name: Digital Downloads with WooCommerce
 * Description: A plugin to manage and track digital downloads with WooCommerce.
 * Version: 1.0
 * Author: Your Name
 */

if (!defined('ABSPATH')) {
    exit;
}

// Create a custom table for tracking downloads
function ddw_create_downloads_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'digital_downloads';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT(20) UNSIGNED NOT NULL,
        product_id BIGINT(20) UNSIGNED NOT NULL,
        order_id BIGINT(20) UNSIGNED NOT NULL,
        download_date DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

register_activation_hook(__FILE__, 'ddw_create_downloads_table');

// Hook into WooCommerce order completion
function ddw_log_download_on_order_complete($order_id) {
    if (!function_exists('wc_get_order')) {
        return;
    }

    $order = wc_get_order($order_id);
    $user_id = $order->get_user_id();

    foreach ($order->get_items() as $item) {
        $product_id = $item->get_product_id();
        global $wpdb;
        $wpdb->insert(
            $wpdb->prefix . 'digital_downloads',
            [
                'user_id' => $user_id,
                'product_id' => $product_id,
                'order_id' => $order_id,
                'download_date' => current_time('mysql'),
            ]
        );
    }
}

add_action('woocommerce_order_status_completed', 'ddw_log_download_on_order_complete');

// Frontend UI: User's download dashboard
function ddw_display_downloads_dashboard() {
    if (!is_user_logged_in()) {
        return '<p>Please <a href="' . wp_login_url() . '">log in</a> to view your downloads.</p>';
    }

    $user_id = get_current_user_id();
    global $wpdb;
    $table_name = $wpdb->prefix . 'digital_downloads';

    $downloads = $wpdb-
